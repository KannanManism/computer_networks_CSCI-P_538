## Follow the guideline [here](https://github.iu.edu/SICE-OS/xinu/wiki/Getting-Started) to build xinu inside docker container

